let Person = require('./person');

result.Person = Person;

let person = new Person('Pesho');
console.log(person.toString());